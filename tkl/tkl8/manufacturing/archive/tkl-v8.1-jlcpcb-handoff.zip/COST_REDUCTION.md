# V8.1 fabrication cost comparison

Reviewed 2026-09-25 against the user's JLC quote for original v8. This is a
revised prototype package for quotation. Existing physical-fit, firmware,
USB/RF bench validation and battery-temperature holds still apply.

## Completed changes

- All 66 vias formerly using 0.15 mm holes / 0.35 mm pads now use
  0.20 mm holes / 0.45 mm pads. Existing larger vias remain larger.
- Local controller/USB escape routing and nearby GPIO/power traces were adjusted
  to maintain the existing 0.127 mm clearance rule. One ROW7 segment now uses
  the existing 0.127 mm minimum trace width. No clearance rule was relaxed.
- Four copper layers, stackup, outline, switch/component positions, pad geometry,
  RF traces and keepouts are retained. Mechanical fit envelopes are identical.
- C14/C15/C22 are Walsin 0603B105K160CT / C108463, as selected in the user's
  order: 1 uF, +/-10%, X7R, 16 V, 0603. The maximum 0.95 mm body height fits
  the existing 1.0 mm envelope. The original AVX part was unavailable.
- BAT46W-7-F diodes remain specified. Cheaper diode alternatives have not been
  approved; this revision's cost target is fabrication.

Validation results are in `../validation/summary.json` and the detailed
before/after fabrication audit is in `../validation/fabrication-cost-audit.json`.
A supplier quote for five v8.1 assembled boards was saved to the user's JLCPCB
cart on 2026-09-25. No order was placed. The live fabrication subtotal is
**$151.75**, a **$22.60** reduction from the original quote. See
[the saved quote record](JLC_QUOTE_2026-09-25.md) for settings and exclusions.

## Quote settings

Upload **tkl-v8.1-gerbers.zip**, **jlcpcb-bom.csv** and **jlcpcb-cpl.csv** from
this directory. Use a fresh quote or re-upload all three files together.

Keep 4 layers, 1.6 mm, the documented JLC04161H-7628 stack, ENIG, green mask,
1 oz outer / 0.5 oz inner copper, filled/planarized/capped vias, Standard PCBA,
both sides, placement confirmation and depaneling. Keep quantities identical
to the original quote when comparing fabrication costs.

Change minimum via size to **0.2 mm hole / 0.45 mm pad**. JLC's quotation page
states that multilayer boards with 0.20 mm holes and pads at least 0.45 mm
have no extra small-via charge. Retain electrical continuity testing; ask for
the ordinary test option rather than the former small-hole-triggered Kelvin
upgrade if the quotation form permits it. If Kelvin remains mandatory after
the revised files are reviewed, that portion of the saving does not apply.
[JLC minimum-via quotation rules](https://cart.jlcpcb.com/quote),
[JLC small-hole surcharges](https://jlcpcb.com/help/article/in-what-cases-will-there-be-charged-extra).

If the form only offers a generic 0.2 mm button, select that actual hole size
and add this PCB remark; do not select 0.3 mm to suppress a charge:

> TKL v8.1: minimum through-via hole 0.20 mm, minimum via pad 0.45 mm.
> Please apply your published multilayer no-surcharge rule for 0.20/0.45 mm
> vias. Retain resin filling, planarization and copper capping for via-in-pad,
> and full electrical continuity testing. Confirm whether a separate Kelvin
> test is still required. Stack JLC04161H-7628, 1.6 mm, four layers.

| Original five-board quote | Amount |
| --- | ---: |
| PCB fabrication subtotal | $174.35 |
| Small-hole surcharge targeted | $45.20 |
| Kelvin-test surcharge potentially removable | $19.77 |
| Fabrication subtotal if only small-hole surcharge disappears | $129.15 |
| Fabrication subtotal if both charges disappear | $109.38 |
| Complete original PCB + PCBA quote, excluding unshown shipping/tax | $425.77 |
| Arithmetic PCB + PCBA target if both charges disappear and all else is unchanged | $360.80 |

These are comparisons using the old quote, not promised prices. Via filling
($22.60), ENIG ($22.20), electrical continuity testing and necessary assembly
inspection remain part of this design. Do not disable via filling to match
the lower target.

The live form still charges **$22.60** for the generic 0.20 mm via selection
and **$19.77** for Kelvin testing. The PCB remark requests review against the
actual 0.20/0.45 mm vias; no further reduction has been confirmed. The form
also requires Horizontal Electroless Copper Plating with Epoxy Filled & Capped
vias. The automatic quote is **$399.86**, excluding **$3.31** depaneling,
shipping/tax and any assembly-remark charge determined after review. Including
the displayed depaneling charge, the comparable total is **$403.17**.

## Original v8 and v7 comparison

The original v8 files are preserved as `archive/tkl-v8-original-0.15mm-gerbers.zip`
and `archive/tkl-v8-original-0.15mm-handoff.zip`; their sources correspond to git
commit `1c7bf4b`. The archived original BOM still names the unavailable AVX cap.

V7 now has a matching **v7.1** fabrication revision, with 0.20/0.45 mm vias
and the C108463 capacitor replacement. Quote it with **bottom-side** assembly,
its own v7.1 Gerber/BOM/CPL files and the same quantities. See the
[v7.1 quote instructions](../../tkl7/manufacturing/COST_REDUCTION.md).
Original v7 archives still require their original 0.15 mm drilling selection.
V7.1 uses different LEDs; do not interchange its BOM/CPL with v8.1.

Six layers remain an alternative to compare if the revised four-layer price is
uncompetitive. JLC advertises included ENIG and via-in-pad for six layers, but
the larger board's base fabrication price must be compared before a stackup
conversion. No six-layer fabrication files were created.
[JLC six-layer pricing features](https://jlcpcb.com/resources/6-layer-pcbs).
