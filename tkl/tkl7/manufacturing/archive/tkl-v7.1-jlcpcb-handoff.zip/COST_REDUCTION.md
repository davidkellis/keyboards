# V7.1 fabrication cost comparison

Updated 2026-09-25. This applies the larger-via fabrication changes from v8.1
to v7 while retaining its bottom-side assembly and reverse-mount LEDs.
Existing physical-fit, battery-temperature, firmware and USB/RF bench
validation holds still apply. Live quotes were obtained on 2026-09-25; no
order was placed. See [the quote comparison](JLC_QUOTE_2026-09-25.md).

Five assembled v7.1 boards are **$399.12** including the displayed DHL shipping
estimate and rail removal, versus **$448.54** for five v8.1 boards. Two assembled
v7.1 boards plus three bare spares are **$330.56** on the same basis. Tax and
any reverse-LED fixture/assembly-remark charges after review are additional.
The two-assembled option is currently saved in the cart.

## Changes

- All 58 former 0.15 mm holes / 0.35 mm via pads now use 0.20 / 0.45 mm.
  The board has 180 vias at 0.20 / 0.45 mm and 93 larger vias at
  0.3048 / 0.6096 mm: 273 vias total.
- Local controller/USB and nearby GPIO/power routing is adjusted for the
  larger vias. The existing 0.127 mm clearance rule is retained; one ROW7
  segment uses the existing 0.127 mm minimum width. No clearance is relaxed.
- Four layers, 1.6 mm thickness, outline, component positions, RF signal
  geometry and keepouts are retained. All six LTW-C230DS reverse-mount LEDs
  and their six 2.1 x 2.8 mm light openings remain unchanged.
- C14/C15/C22 use Walsin 0603B105K160CT / C108463, the same replacement
  selected for v8: 1 uF, +/-10%, X7R, 16 V, 0603. Maximum 0.95 mm body height
  fits the existing 1.0 mm component envelope.
- The 86 BAT46W-7-F diodes remain specified; no diode substitution is made.

See `../validation/summary.json` for electrical checks and
`../validation/fabrication-cost-audit.json` for the before/after routing and
geometry audit. The existing case/plate/PCB fit models still apply.

## Quote settings

Upload **tkl-v7.1-gerbers.zip**, **jlcpcb-bom.csv** and **jlcpcb-cpl.csv** from
this directory together. Select **Bottom Side** assembly: 140 bottom SMT
placements and two bottom-inserted THT connectors per board, in 31 BOM groups.
Use matching quantities when comparing v7.1 against v8.1.

Keep four layers, 1.6 mm, the JLC04161H-7628 stack, green mask, ENIG,
1 oz outer / 0.5 oz inner copper, filled/planarized/copper-capped vias,
full electrical continuity testing and placement confirmation. Have any
temporary assembly rails removed before delivery so the board fits the case.

Choose the **0.20 mm minimum-hole option**, with **0.45 mm minimum via pads**.
JLC's published multilayer rule exempts this combination from its small-via
surcharge. If the UI has only a generic 0.20 mm button, choose it and add the
remark below. Do not choose a larger hole size than the actual design.
[JLC minimum-via pricing rule](https://cart.jlcpcb.com/quote/?fromDemo=yes).

> TKL v7.1: minimum through-via hole 0.20 mm, minimum via pad 0.45 mm.
> Please apply your published multilayer no-surcharge rule for 0.20/0.45 mm
> vias. Retain resin filling, planarization and copper capping for via-in-pad,
> and full electrical continuity testing. Confirm whether a separate Kelvin
> test is still required. Stack JLC04161H-7628, 1.6 mm, four layers.
> Bottom-side assembly only. Preserve all six reverse-LED NPTH slots.

The previous **v8** quote charged $45.20 for small holes and $19.77 for a
Kelvin test. Those are the charges targeted by the same geometry change;
they are not a quoted v7 saving or a guaranteed $64.97 discount. Request the
ordinary continuity test if JLC permits it; retain Kelvin testing if it remains
required after review. Via filling and ENIG remain necessary.

V7.1 permits **single-side Standard assembly**. Economic PCBA was tested with
the exact BOM on 2026-09-25: JLC marks U1, NRF52840-QIAA-R7 / C1851953,
**Standard Only**. The system leaves U1 unselected until switching to Standard.
Therefore an Economic quote excluding U1 is not a complete-board alternative.
Use **Standard PCBA / Bottom Side**. The general capabilities permit the board
size and SMT/THT combination; the specific controller listing is the blocker.
[JLC assembly capabilities](https://jlcpcb.com/capabilities/pcb-assembly-capabilities).

Both Standard quotes still charge $22.60 for the generic 0.20 mm via option
and $19.77 for Kelvin testing. Those fees have been flagged for review in the
PCB remark, but their removal has not been agreed. Filled/capped vias and ENIG
remain required. The form requires Horizontal Electroless Copper Plating with
filled/capped vias.

## Original files and v8 comparison

The original v7 Gerbers and full handoff are preserved in
`archive/tkl-v7-original-0.15mm-gerbers.zip` and
`archive/tkl-v7-original-0.15mm-handoff.zip`; source baseline is git commit
`1c7bf4b`. These original archives retain the old small vias and unavailable
capacitor selection. Use the v7.1 files for the revised quote.

V8.1 uses different LEDs and both-side assembly. Use its own Gerber/BOM/CPL
files and select Both Sides when comparing; do not mix its assembly files
with v7.1. Neither package includes switches, the battery or firmware.
